import { getTasks, saveTasks, deleteTask } from './storage.js';
import { renderTasksGroupedByDate } from './render.js';
import { initModal, openModalWithData, getCurrentTaskId, clearCurrentTaskId } from './modal.js';
import { initFilters, applyFilters } from './filters.js';

import { showToast } from './utils.js';

document.addEventListener('DOMContentLoaded', () => {
    showToast('¡Este es un toast de prueba!', 'success');
    const tasks = getTasks();
    renderTasksGroupedByDate(tasks);
    initModal('task-modal', 'task-form', 'btn-open', 'btn-cancel');

    const form = document.getElementById('task-form');
    const modal = document.getElementById('task-modal');

    let lastKnownTasks = getTasks();
    setInterval(() => {
        const updatedTasks = getTasks();
        const now = new Date().toISOString().split('T')[0];

        updatedTasks.forEach(task => {
            const oldTask = lastKnownTasks.find(t => t.id === task.id);
            if (!oldTask) return;

            const wasToday = oldTask.date === now;
            const isPast = task.date < now;

            if (wasToday && isPast) {
                showToast(`"${task.title}" pasó de hoy a vencida`, 'warning');
            }
        });
        lastKnownTasks = JSON.parse(JSON.stringify(updatedTasks)); // Clon profundo
    }, 60000);

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const taskId = getCurrentTaskId();
        const tasks = getTasks();

        const task = {
            id: taskId || Date.now().toString(),
            title: document.getElementById('task-title').value.trim(),
            description: document.getElementById('task-desc').value.trim(),
            category: document.getElementById('task-category').value.trim(),
            priority: document.getElementById('task-priority').value,
            date: document.getElementById('task-date').value,
            time: document.getElementById('task-time').value,
            completed: false
        };

        const updatedTasks = taskId
            ? tasks.map(t => t.id === taskId ? task : t)
            : [...tasks, task];

        saveTasks(updatedTasks);
        renderTasksGroupedByDate(updatedTasks);
        applyFilters();

        // ✅ Alerta toast
        showToast(
            `"${task.title}" ${taskId ? 'actualizada' : 'creada'}`,
            taskId ? 'info' : 'success'
        );

        form.reset();
        clearCurrentTaskId();
        modal.classList.add('hidden');
    });


    const btnDelete = document.getElementById('btn-delete');
    btnDelete.addEventListener('click', () => {
        const id = getCurrentTaskId();
        if (id && confirm("¿Eliminar esta tarea?")) {
            deleteTask(id);
            renderTasksGroupedByDate(getTasks());
            applyFilters();
            clearCurrentTaskId();
            modal.classList.add('hidden');

            const task = getTasks().find(t => t.id === id);
            if (task) {
                showToast(`"${task.title}" eliminada`, 'error');
            }
        }
    });



    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('btn-edit')) {
            const taskId = e.target.dataset.id;
            const task = getTasks().find(t => t.id === taskId);
            if (task) openModalWithData(task, 'task-modal', 'task-form');
        }
    });
    // Filtros
    initFilters(applyFilters);

    // Autoactualizar tareas cada minuto (solo si modal está cerrado)
    setInterval(() => {
        const modal = document.getElementById('task-modal');
        if (modal.classList.contains('hidden')) {
            const tasks = getTasks();
            renderTasksGroupedByDate(tasks);
            applyFilters();
        }
    }, 60000);


    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', function (e) {
                const ripple = document.createElement('span');
                ripple.classList.add('ripple');

                // Posición del click dentro del botón
                const rect = btn.getBoundingClientRect();
                ripple.style.left = `${e.clientX - rect.left}px`;
                ripple.style.top = `${e.clientY - rect.top}px`;

                // Tamaño del ripple (opcional)
                ripple.style.width = ripple.style.height = Math.max(btn.offsetWidth, btn.offsetHeight) + 'px';

                // Agrega y elimina
                this.appendChild(ripple);
                setTimeout(() => ripple.remove(), 600);
            });
        });
    });






function updateConnectionStatus() {
  const btn = document.getElementById('btn-open');
  const icon = document.getElementById('connection-status');

  if (navigator.onLine) {
    showToast("Conectado a Internet", "success");
    btn.classList.add('online');
    btn.classList.remove('offline');
    icon.textContent = '＋'; // ícono normal
    btn.title = "Nueva tarea (Conectado)";
  } else {
    showToast("Sin conexión a Internet", "danger");
    btn.classList.add('offline');
    btn.classList.remove('online');
    icon.textContent = '×'; // o '✖', o mantener '＋'
    btn.title = "Sin conexión";
  }
}

// Detectar estado inicial
window.addEventListener('load', updateConnectionStatus);

// Detectar cambios de conexión
window.addEventListener('online', updateConnectionStatus);
window.addEventListener('offline', updateConnectionStatus);

});
