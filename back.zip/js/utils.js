import { getTasks, saveTasks } from './storage.js';
import { renderTasksGroupedByDate } from './render.js';


export function getPriorityColor(priority) {
    switch (priority) {
        case 'alta': return '#e74c3c';
        case 'media': return '#f39c12';
        case 'baja': return '#2ecc71';
        default: return '#bdc3c7';
    }
}


export function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container') || createToastContainer();
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const icons = {
        success: '✅',
        warning: '⚠️',
        danger: '❌',
        info: 'ℹ️'
    };

    toast.innerHTML = `
    <span class="toast-icon">${icons[type] || ''}</span>
    <span class="toast-message">${message}</span>
  `;

    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 4000);
}

function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.style.position = 'fixed';
    container.style.top = '1rem';
    container.style.right = '1rem';
    container.style.zIndex = '10000';
    document.body.appendChild(container);
    return container;
}

export function showDeleteToast(task) {
  const toastContainer = document.getElementById('toast-container') || createToastContainer();
  const toast = document.createElement('div');
  toast.className = `toast toast-black`;

  toast.innerHTML = `
    <div class="toast-header">
    <span class="toast-title"><button class="close-toast" title="Cerrar">❌</button><strong>"${task.title}"<br></strong></span>
      <p class="toast-message">¿Estás seguro de eliminar?</p>
    </div>
    <div class="toast-body">
      
      <div class="toast-actions">
      
      
      
      <br>
        <button class="btn-toast-confirm">Eliminar</button>
        <button class="btn-toast-cancel">Cancelar</button>
      </div>
    </div>
  `;

  toastContainer.appendChild(toast);

  // Evento: Confirmar eliminación
  toast.querySelector('.btn-toast-confirm').addEventListener('click', () => {
    const updatedTasks = getTasks().filter(t => t.id !== task.id);
    saveTasks(updatedTasks);
    renderTasksGroupedByDate(updatedTasks);
    toast.remove();
    showToast(`"${task.title}" fue eliminada`, 'danger');
  });

  // Evento: Cancelar
  toast.querySelector('.btn-toast-cancel').addEventListener('click', () => {
    toast.remove();
  });

  // Evento: Cerrar manual con botón (×)
  toast.querySelector('.close-toast').addEventListener('click', () => {
    toast.remove();
  });

  // Auto eliminar después de cierto tiempo
  setTimeout(() => {
    toast.remove();
  }, 8000);
}

