let currentDateFilter = 'all';
let currentPriorityFilter = 'all';
let currentSearch = '';

export function initFilters(updateCallback) {
    document.querySelectorAll('.filter-btn-date').forEach(btn => {
        btn.addEventListener('click', () => {
            currentDateFilter = btn.dataset.filter;
            document.querySelectorAll('.filter-btn-date').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            updateCallback();
        });
    });

    document.querySelectorAll('.filter-btn-priority').forEach(btn => {
        btn.addEventListener('click', () => {
            currentPriorityFilter = btn.dataset.priority;
            document.querySelectorAll('.filter-btn-priority').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Aplica clase de borde a los inputs según la prioridad seleccionada
            const formInputs = document.querySelectorAll('input, select, textarea');
            formInputs.forEach(input => {
                input.classList.remove('borde-urgente', 'borde-normal', 'borde-leve');
                if (currentPriorityFilter !== 'all') {
                    input.classList.add(`borde-${currentPriorityFilter}`);
                }
            });

            updateCallback();
        });
    });

    document.getElementById('search-input').addEventListener('input', (e) => {
        currentSearch = e.target.value.toLowerCase();
        updateCallback();
    });

    document.getElementById('btn-clear-filters').addEventListener('click', () => {
        currentDateFilter = 'all';
        currentPriorityFilter = 'all';
        currentSearch = '';
        document.getElementById('search-input').value = '';
        document.querySelectorAll('.filter-btn-date, .filter-btn-priority').forEach(btn => btn.classList.remove('active'));
        updateCallback();
    });
}

export function applyFilters() {
    const groups = document.querySelectorAll('.task-date-group');

    groups.forEach(group => {
        const status = group.classList.contains('past') ? 'past' :
            group.classList.contains('today') ? 'today' :
                group.classList.contains('future') ? 'future' : 'unknown';

        const showByDate = (currentDateFilter === 'all' || status === currentDateFilter);

        const tasks = group.querySelectorAll('.task-item');
        let hasVisibleTasks = false;

        tasks.forEach(task => {
            const priority = task.classList.contains('priority-alta') ? 'alta' :
                task.classList.contains('priority-media') ? 'media' :
                    task.classList.contains('priority-baja') ? 'baja' : 'otro';

            const content = task.textContent.toLowerCase();
            const matchesPriority = (currentPriorityFilter === 'all' || currentPriorityFilter === priority);
            const matchesSearch = content.includes(currentSearch);

            const visible = showByDate && matchesPriority && matchesSearch;
            task.style.display = visible ? '' : 'none';

            if (visible) hasVisibleTasks = true;
        });

        group.style.display = hasVisibleTasks ? '' : 'none';
    });
}
