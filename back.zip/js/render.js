import { getTasks, saveTasks, deleteTask } from './storage.js';
import { showToast, showDeleteToast } from './utils.js';


export function renderTasksGroupedByDate(tasks) {
  const taskList = document.getElementById('task-list');
  taskList.innerHTML = '';

  if (tasks.length === 0) {
    taskList.innerHTML = '<p>No hay tareas aún.</p>';
    return;
  }

  const grouped = tasks.reduce((acc, task) => {
    const date = task.date || 'Sin fecha';
    if (!acc[date]) acc[date] = [];
    acc[date].push(task);
    return acc;
  }, {});

  const sortedDates = Object.keys(grouped).sort((a, b) => {
    if (a === 'Sin fecha') return 1;
    if (b === 'Sin fecha') return -1;
    return getEarliestDateTime(grouped[a]) - getEarliestDateTime(grouped[b]);
  });

  sortedDates.forEach(date => {
    const dateGroup = document.createElement('div');
    const firstTask = grouped[date][0];
    const status = getDateGroupStatus(date, firstTask.time || '00:00');

    dateGroup.className = `task-date-group ${status}`;

    const title = document.createElement('h3');
    title.textContent = formatDate(date);
    dateGroup.appendChild(title);

    grouped[date].sort((a, b) => {
      const timeA = a.time || '00:00';
      const timeB = b.time || '00:00';
      return timeA.localeCompare(timeB);
    });

    grouped[date].forEach(task => {
      const template = document.getElementById('task-template');
      const clone = template.content.cloneNode(true);
      const li = clone.querySelector('li');
      li.classList.add(`priority-${task.priority}`, `border-priority-${task.priority}`);
      if (task.completed) li.classList.add('completed');
      li.dataset.id = task.id;

      clone.querySelector('.task-title').textContent = task.title;
      const desc = clone.querySelector('.task-desc');
      if (task.description) {
        desc.textContent = task.description;
      } else {
        desc.remove(); // eliminar si no hay
      }

      clone.querySelector('.task-meta').textContent =
        `${task.category || 'Sin categoría'} - Prioridad: ${task.priority}`;
      clone.querySelector('.task-datetime').textContent = `🗓️ ${formatDateTime(task.date, task.time)}`;

      // Botones
      const completeBtn = clone.querySelector('.btn-complete');
      if (task.completed) {
        completeBtn.innerHTML = '❌ Deshacer';
        completeBtn.classList.remove('pending');
        completeBtn.classList.add('done');
      } else {
        completeBtn.innerHTML = '✔️ Completar';
        completeBtn.classList.remove('done');
        completeBtn.classList.add('pending');
      }
      completeBtn.addEventListener('click', () => {
        task.completed = !task.completed;

        if (task.completed) {
          completeBtn.innerHTML = '❌ Deshacer';
          completeBtn.classList.remove('pending');
          completeBtn.classList.add('done');
        } else {
          completeBtn.innerHTML = '✔️ Completar';
          completeBtn.classList.remove('done');
          completeBtn.classList.add('pending');
        }


        const updated = getTasks().map(t => t.id === task.id ? task : t);
        saveTasks(updated);
        renderTasksGroupedByDate(updated);

        showToast(
          `"${task.title}" fue ${task.completed ? 'completada' : 'desmarcada'}`,
          task.completed ? 'success' : 'info'
        );
      });

      const editBtn = clone.querySelector('.btn-edit');
      editBtn.textContent = '✏️ Editar';
      editBtn.dataset.id = task.id;

      const deleteBtn = clone.querySelector('.btn-delete-inline');
      deleteBtn.textContent = '🗑️ Eliminar';
      deleteBtn.addEventListener('click', () => {
        showDeleteToast(task);
      });

      dateGroup.appendChild(clone);
    });

    taskList.appendChild(dateGroup);
  });
}

// Funciones auxiliares sin cambios
function getEarliestDateTime(taskArray) {
  return taskArray.reduce((min, t) => {
    if (!t.date) return min;
    const [y, m, d] = t.date.split('-').map(Number);
    const [hh, mm] = (t.time || '00:00').split(':').map(Number);
    const localDate = new Date(y, m - 1, d, hh, mm);
    return localDate < min ? localDate : min;
  }, new Date(3000, 0, 1));
}

function formatDate(dateStr) {
  if (dateStr === 'Sin fecha') return dateStr;
  const [year, month, day] = dateStr.split('-');
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('es-PE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

function formatDateTime(dateStr, timeStr) {
  if (!dateStr) return 'Sin fecha';
  const [year, month, day] = dateStr.split('-');
  const [hour, minute] = (timeStr || '00:00').split(':');
  const date = new Date(year, month - 1, day, hour, minute);
  return date.toLocaleString('es-PE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function getDateGroupStatus(dateStr, timeStr = '00:00') {
  if (dateStr === 'Sin fecha') return 'future op-50';

  const now = new Date();
  const [year, month, day] = dateStr.split('-');
  const [hour, minute] = timeStr.split(':');
  const taskDate = new Date(year, month - 1, day, hour, minute);

  if (taskDate < now) return 'past';

  const today = new Date();
  if (
    taskDate.getFullYear() === today.getFullYear() &&
    taskDate.getMonth() === today.getMonth() &&
    taskDate.getDate() === today.getDate()
  ) return 'today';

  return 'future';
}
